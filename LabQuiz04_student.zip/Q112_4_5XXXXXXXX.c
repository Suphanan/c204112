/* ชื่อ นามสกุล
 * 5XXXXXXXX
 * Quiz 04
 * 204112 Sec 00A */

#include "Q112_4.h"


student_node_t *create_student_node(char student_id[], char first_name[], char last_name[], double gpa)
{


    return NULL;
}



student_node_t *find_student_by_id(student_class_t s_class[], char student_id[])
{
    return NULL;
}




void compute_class_stat(student_class_t s_class[], int year)
{



}



void print_id(student_class_t s_class[], int year)
{

    int index = year - START_YEAR;
    student_node_t *curr = s_class[index].student_list_head;

    while (curr->next != NULL) {
        printf("%s", curr->student_id);
        if (curr->next != NULL) {
            printf(" ");
        }
        curr = curr->next;
    }
    printf("\n");
}



void print_id_reverse(student_class_t s_class[], int year)
{

}