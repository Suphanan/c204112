#include "Q112_4.h"



void delete_all(student_class_t s_class[])
{
    int i = 0;
    for (i = 0; i < MAX_CLASS; i++) {
        delete_class_list(s_class[i].student_list_head);
        s_class[i].student_list_head = NULL;
    }
}


void delete_class_list(student_node_t *head)
{

    student_node_t *curr = head;
    student_node_t *next = NULL;
    while (curr != NULL) {
        next = curr->next;
        free(curr);
        curr = next;
    }
}



int get_index_by_id(char student_id[])
{
    char year_str[3] = {};
    strncpy(year_str, student_id, 2);
    int year = atoi(year_str);
    int index = year - START_YEAR;
    return index;
}
// -------------------------- INSERT


void insert_student_in_order(student_class_t s_class[], student_node_t *newNode)
{

    int index = get_index_by_id(newNode->student_id);
    s_class[index].student_list_head = insert_node(s_class[index].student_list_head, newNode);
    s_class[index].student_count++;

}

student_node_t *insert_node(student_node_t *head, student_node_t *newNode)
{
    if ((head == NULL) || strcmp(newNode->student_id, head->student_id) < 0) {
        newNode->next = head;
        return newNode;
    }
    student_node_t *curr;
    for (curr = head; curr->next != NULL; curr = curr->next) {
        if (strcmp(curr->next->student_id, newNode->student_id) > 0) {
            break;
        }
    }

    newNode->next = curr->next;
    curr->next = newNode;
    return head;
}


// -------------------------- DELETE
int delete_student(student_class_t s_class[], char student_id[])
{
    int success = 0;
    char year_str[3] = {};
    strncpy(year_str, student_id, 2);
    int year = atoi(year_str);
    int index = year - START_YEAR;
    s_class[index].student_list_head = delete_node(s_class[index].student_list_head, student_id, &success);
    if (success == 1) {
        s_class[index].student_count--;
    }
    return success;
}


student_node_t *delete_node(student_node_t *head, char student_id[], int *success)
{
    *success = 0;
    student_node_t *curr, *temp = NULL;

    if (!head) {
        return NULL;
    }

    if (strcmp(head->student_id, student_id) == 0) {
        temp = head->next;
        free(head);
        *success = 1;
        return temp;
    }

    curr = head;

    while (curr->next != NULL) {
        if (strcmp(curr->next->student_id, student_id) >= 0) {
            break;
        }
        curr = curr->next;
    }

    if (curr->next && (strcmp(curr->next->student_id , student_id) == 0)) {
        temp = curr->next;
        curr->next = curr->next->next;
        free(temp);
        *success = 1;
    }
    return head;
}

void print_class_stat(student_class_t s_class[], int year)
{
    int index = year - START_YEAR;
    student_class_t curr = s_class[index];
    printf("<%d> ave: %.2f | min: %.2f | max: %.2f | total: %d\n", year, curr.average_gpa, curr.min_gpa, curr.max_gpa, curr.student_count);
    
}

