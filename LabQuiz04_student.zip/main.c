#include "Q112_4.h"

int main()
{
    int count, i;
    char command[2];

    int success = 0;

    student_node_t *newNode;
    student_node_t *curr;

    char student_id[ID_LEN + 1];
    char f_name[NAME_LEN + 1];
    char l_name[NAME_LEN + 1];
    double gpa;

    int year;

    student_class_t s_class[MAX_CLASS] = {};

    scanf("%d", &count);

    for (i = 1; i <= count; i++) {
        scanf("%s", command);
        switch (command[0]) {
        case 'i':
            scanf("%s %s %s %lf", student_id, f_name, l_name, &gpa);
            newNode = create_student_node(student_id,  f_name, l_name,  gpa);
            insert_student_in_order(s_class, newNode);
            break;
        case 'd':
            scanf("%s", student_id);
            success = delete_student(s_class,  student_id);

            if (success == 1) {
                printf("%s [deleted]\n", student_id);
            } else {
                printf("%s [not deleted]\n", student_id);
            }
            break;
        case 'f':

            scanf("%s", student_id);
            curr = find_student_by_id( s_class, student_id);

            if (curr != NULL) {
                printf("%s [found] %s %s\n", student_id, curr->first_name, curr->last_name);
            } else {
                printf("%s [not found]\n", student_id);
            }
            break;

        case 's':
            scanf("%d", &year);
            compute_class_stat(s_class, year);
            print_class_stat(s_class, year);
            break;

        case 'p':
            scanf("%d", &year);
            print_id(s_class, year);
            break;

        case 'r':
            scanf("%d", &year);
            print_id_reverse(s_class, year);
            break;
        }
    }

    delete_all(s_class);
    return 0;
}

