#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CLASS 45
#define NAME_LEN 20
#define ID_LEN 9
#define START_YEAR 55


typedef struct student_node {
    char student_id[ID_LEN + 1];            // รหัสนักศึกษา
    char first_name[NAME_LEN + 1];  // ชือ
    char last_name[NAME_LEN + 1];   // นามสกุล
    double gpa;                     // เกรดเฉลี่ยสะสม
    struct student_node *next;      // Pointer ไปยัง node ถัดไป


} student_node_t;

typedef struct student_class {

    int student_count;  // จำนวนนักศึษา
    double average_gpa; // เกรดเฉลี่ยรวมของชั้นปี
    double min_gpa;     // เกรดเฉลี่ยต่ำสุด
    double max_gpa;     // เกรดเฉลี่ยสูงสุด

    struct student_node *student_list_head;     // Linked List ของข้อมูลนักศึกษาแค่ละคน

} student_class_t;


// prototypes

student_node_t *create_student_node(char id[], char first_name[], char last_name[], double gpa);
student_node_t *find_student_by_id(student_class_t s_class[], char student_id[]);
void compute_class_stat(student_class_t s_class[], int year);
void print_id(student_class_t s_class[], int year);
void print_id_reverse(student_class_t s_class[], int year);



// HELPER FUNCTIONS (helper.c)
int get_index_by_id(char student_id[]);

void insert_student_in_order(student_class_t s_class[], student_node_t *newNode);
student_node_t *insert_node(student_node_t *head, student_node_t *newNode);

int delete_student(student_class_t s_class[], char student_id[]);
student_node_t *delete_node(student_node_t *head, char student_id[], int *success);

void delete_all(student_class_t s_class[]);
void delete_class_list(student_node_t *head);
void print_class_stat(student_class_t s_class[], int year);